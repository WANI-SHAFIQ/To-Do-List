document.addEventListener('DOMContentLoaded', function () {
    const taskInput = document.getElementById('taskInput');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const taskList = document.getElementById('taskList');

    // Load tasks from local storage
    loadTasks();

    addTaskBtn.addEventListener('click', function () {
        const taskText = taskInput.value.trim();
        if (taskText) {
            addTask(taskText);
            taskInput.value = '';
            saveTasks();
        }
    });

    taskList.addEventListener('click', function (e) {
        if (e.target.classList.contains('edit-btn')) {
            editTask(e.target.closest('li'));
        } else if (e.target.classList.contains('delete-btn')) {
            deleteTask(e.target.closest('li'));
            saveTasks();
        } else if (e.target.tagName === 'LI') {
            e.target.classList.toggle('completed');
            saveTasks();
        }
    });

    function addTask(taskText) {
        const li = document.createElement('li');
        li.innerHTML = `
            <span>${taskText}</span>
            <div>
                <button class="edit-btn">Edit</button>
                <button class="delete-btn">Delete</button>
            </div>
        `;
        taskList.appendChild(li);
    }

    function editTask(taskItem) {
        const taskText = taskItem.querySelector('span').textContent;
        const newTaskText = prompt('Edit your task:', taskText);
        if (newTaskText) {
            taskItem.querySelector('span').textContent = newTaskText;
            saveTasks();
        }
    }

    function deleteTask(taskItem) {
        taskItem.remove();
    }

    function saveTasks() {
        const tasks = [];
        document.querySelectorAll('li').forEach(taskItem => {
            tasks.push({
                text: taskItem.querySelector('span').textContent,
                completed: taskItem.classList.contains('completed')
            });
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.forEach(task => {
            addTask(task.text);
            if (task.completed) {
                taskList.lastChild.classList.add('completed');
            }
        });
    }
});
